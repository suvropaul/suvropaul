# modules and utilities for making win32 installer
